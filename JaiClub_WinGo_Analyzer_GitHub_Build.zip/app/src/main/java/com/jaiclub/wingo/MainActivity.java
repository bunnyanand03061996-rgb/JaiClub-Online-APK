package com.jaiclub.wingo;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private WebView web;
    private final java.util.concurrent.ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new ApiBridge(), "JaiApi");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    public class ApiBridge {
        @JavascriptInterface
        public String getHistory(String gameCode) {
            if (!"WinGo_1M".equals(gameCode) && !"WinGo_30S".equals(gameCode)) {
                return "{\"error\":\"Unsupported game mode\"}";
            }
            HttpURLConnection conn = null;
            try {
                URL url = new URL("https://draw.ar-lottery06.com/WinGo/" + gameCode + "/GetHistoryIssuePage.json");
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(12000);
                conn.setReadTimeout(12000);
                conn.setRequestProperty("Accept", "application/json");
                conn.setRequestProperty("User-Agent", "JaiClubWinGoAnalyzer/1.0");
                int status = conn.getResponseCode();
                BufferedReader reader = new BufferedReader(new InputStreamReader(
                    status >= 200 && status < 300 ? conn.getInputStream() : conn.getErrorStream(), "UTF-8"));
                StringBuilder body = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) body.append(line);
                reader.close();
                if (status < 200 || status >= 300) return "{\"error\":\"HTTP " + status + "\"}";
                return body.toString();
            } catch (Exception ex) {
                try { return new JSONObject().put("error", ex.getMessage() == null ? "Network error" : ex.getMessage()).toString(); }
                catch (Exception ignored) { return "{\"error\":\"Network error\"}"; }
            } finally {
                if (conn != null) conn.disconnect();
            }
        }
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        executor.shutdownNow();
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
