package com.jaiclub.wingo;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.widget.*;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
  WebView web;
  @Override public void onCreate(Bundle b){super.onCreate(b); web=new WebView(this); setContentView(web);
    WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
    web.setWebViewClient(new WebViewClient()); web.addJavascriptInterface(new Bridge(),"AndroidBridge");
    web.loadUrl("file:///android_asset/index.html");
  }
  class Bridge {
    @JavascriptInterface public void fetchResults(String game){
      new Thread(()->{
        String out;
        try{
          String base="https://draw.ar-lottery06.com/WinGo/WinGo_"+(game.equals("30S")?"30S":"1M")+".json";
          HttpURLConnection c=(HttpURLConnection)new URL(base+"?t="+System.currentTimeMillis()).openConnection();
          c.setRequestMethod("GET"); c.setConnectTimeout(12000); c.setReadTimeout(12000);
          c.setRequestProperty("User-Agent","Mozilla/5.0 WinGoAnalyzer/1.0");
          InputStream in=c.getInputStream(); ByteArrayOutputStream buf=new ByteArrayOutputStream();
          byte[] x=new byte[8192]; int n; while((n=in.read(x))!=-1)buf.write(x,0,n);
          out=buf.toString("UTF-8"); c.disconnect();
        }catch(Exception e){out="{\\"error\\":"+JSONObject.quote(e.getMessage())+"}";}
        final String result=out;
        runOnUiThread(()->web.evaluateJavascript("window.onNativeResults && window.onNativeResults("+JSONObject.quote(result)+")",null));
      }).start();
    }
  }
}